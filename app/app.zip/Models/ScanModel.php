<?php

namespace App\Models;

use CodeIgniter\Model;

class ScanModel extends Model
{
    protected $table = 'user_scan';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id_employee', 'id_student', 'status', 'date', 'note'];
    protected $returnType       = 'array';

    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';

    protected $skipValidation = true;
    
    
      public function getAllScan()
    {
        return $this->select('user_scan.*, ue.name AS employee, us.name AS student')
            ->join('user_employee ue', 'ue.id = user_scan.id_employee', 'left')
            ->join('user_student us', 'us.id = user_scan.id_student', 'left')
            ->orderBy('user_scan.created_at', 'DESC')
            ->findAll();
    }
}
