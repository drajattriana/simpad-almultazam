<?php

namespace App\Controllers;

use App\Models\ScanModel;
use App\Models\StudentModel;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\LabelAlignment;
// -----------------------------------------

use CodeIgniter\HTTP\RedirectResponse;

class StudentController extends BaseController
{
    private function _renderView(string $viewPath, array $pageData): string
    {
        $authDataForView = $this->authData;
        $data = array_merge($authDataForView, $pageData);
        return view($viewPath, $data);
    }

    public function student($params = "", $id = ""): string|RedirectResponse
    {
        if ($params == 'add') {
            $postData = $this->request->getPost();
            $wa = $postData['whatsapp'];
            $wa2 = $postData['dormitory_wa'];

            // Bersihkan spasi & simbol
            $wa = preg_replace('/[^0-9]/', '', $wa);
            $wa2 = preg_replace('/[^0-9]/', '', $wa2);

            // Jika diawali 0 → ganti jadi 62
            if (substr($wa, 0, 1) == '0') {
                $wa = '62' . substr($wa, 1);
            }
            if (substr($wa2, 0, 1) == '0') {
                $wa2 = '62' . substr($wa2, 1);
            }

            // Jika diawali 8 → tambahkan 62
            else if (substr($wa, 0, 1) == '8') {
                $wa = '62' . $wa;
            }
            else if (substr($wa2, 0, 1) == '8') {
                $wa2 = '62' . $wa2;
            }

            // Masukkan kembali ke postData
            $postData['whatsapp'] = $wa;
            $postData['dormitory_wa'] = $wa2;

            if (empty($postData['nis'])) {
                session()->setFlashdata("error", "NIS tidak boleh kosong!");
                return redirect()->back()->withInput();
            }

            $qrData = $postData['nis'];
            $qrFileName = $qrData . '.png';
            $qrPath = FCPATH . 'upload/qr/';

            if (!is_dir($qrPath)) {
                mkdir($qrPath, 0777, true);
            }

            $qrCode = new QrCode($qrData);
            $qrCode->setSize(300);
            $qrCode->setMargin(10);
            // $qrCode->setErrorCorrectionLevel(ErrorCorrectionLevel::HIGH);
            $qrCode->setEncoding('UTF-8');
            $qrCode->setLabel($postData['name']);
            $qrCode->setLabelFontSize(16);
            $qrCode->setLabelAlignment(LabelAlignment::CENTER);

            $qrCode->writeFile($qrPath . $qrFileName);
            // ====================================================

            $uploadSiswa = $postData;
            unset($uploadSiswa['model'], $uploadSiswa['color'], $uploadSiswa['grade'], $uploadSiswa['note'], $uploadSiswa['status']);
            $this->studentModel->save($uploadSiswa);

            $data_student = $this->studentModel->where('nis', $postData['nis'])->first();
            $uploadIpad = [
                'model' => $postData['model'],
                'color' => $postData['color'],
                'grade' => $postData['grade'],
                'note' => $postData['note'],
                'status' => $postData['status'],
                'nis' => $postData['nis'],
                'id_student' => $data_student['id'],
            ];
            $this->ipadModel->save($uploadIpad);

            session()->setFlashdata("success", "Data Student has been successfully added!");
            return redirect()->to('siswa');
        } elseif ($params == 'update') {
            $postData = $this->request->getPost();
            $this->studentModel->update($postData['id'], $postData);
            session()->setFlashdata("success", "Data Student has been successfully updated!");
            return redirect()->to('siswa');
        } elseif ($params == 'delete') {
            $student = $this->studentModel->find($id);

            if ($student) {
                $qrFileName = $student['nis'] . '.png';
                $qrFilePath = FCPATH . 'upload/qr/' . $qrFileName;

                if (file_exists($qrFilePath)) {
                    unlink($qrFilePath);
                }
                $this->studentModel->delete($id);

                session()->setFlashdata("success", "Data Student has been successfully deleted!");
            } else {
                session()->setFlashdata("error", "Data Student not found!");
            }

            return redirect()->to('siswa');
        } else {
            $studentData = $this->studentModel->getAllStudent();
            $classData = $this->classModel->findAll();
            return $this->_renderView('student/student', [
                'title' => 'Siswa',
                'hal' => '4',
                'student' => $studentData,
                'classData' => $classData
            ]);
        }
    }



    public function ipad($params = "", $id = ""): string|RedirectResponse
    {
        if ($params == 'update') {
            $postData = $this->request->getPost();
            $this->ipadModel->update($postData['id'], $postData);
            session()->setFlashdata("success", "Data Role has been successfully updated!");
            return redirect()->to('siswa/ipad');
        } else {
            $ipadData = $this->ipadModel->getAllIpad();
            return $this->_renderView('student/ipad', [
                'title' => 'User Ipad',
                'hal' => '5',
                'ipad' => $ipadData,
            ]);
        }
    }





    public function scan($params = "", $id = ""): string|RedirectResponse
    {
        if ($params == '') {
            $scanData = $this->scanModel->getAllScan();
            return $this->_renderView('student/scan_list', [
                'title' => 'Scan IPad',
                'hal' => '6',
                'scan' => $scanData,
            ]);
        } elseif($params=='Pinjam'){
            $tanggalPengembalian = $this->request->getGet('tanggal_pengembalian');
            $keterangan = $this->request->getGet('keterangan');
            return $this->_renderView('student/scan_pinjam', [
                'title' => 'Scan IPad',
                'hal' => '6',
                'scan' => $params,
                'pengembalian' => $tanggalPengembalian,
                'keterangan' => $keterangan
            ]);
        } else {
            return $this->_renderView('student/scan', [
                'title' => 'Scan IPad',
                'hal' => '6',
                'scan' => $params,
            ]);
        }
    }


    public function processScan()
    {
        $this->response->setContentType('application/json');

        try {
            // Ambil JSON terlebih dulu, fallback ke POST jika kosong
            $data = $this->request->getJSON(true);
            if (!$data) {
                $data = $this->request->getPost(); // fallback untuk form-encoded
            }

            $qr = $data['qr'] ?? null;
            $method = $data['method'] ?? null; // konsisten: method dari payload JSON atau POST



            if (!$qr) {
                session()->setFlashdata('error', 'QR tidak ditemukan.');
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'QR tidak ditemukan.'
                ]);
            }

            // Validasi QR: ganti sesuai kebutuhan
            $isValid = true;
            if (!$isValid) {
                session()->setFlashdata('error', 'QR tidak valid atau tidak terdaftar.');
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'QR tidak valid atau tidak terdaftar.'
                ]);
            }

            $data_employee = $this->employeeModel->where('id_user', session()->get('id_user'))->first();
            $data_student = $this->studentModel->where('nis', $qr)->first();
            $data_ipad = $this->ipadModel->where('nis', $qr)->first();
            if ($method == 'Pinjam') {
                $uploadIpad = [
                'id_employee' => $data_employee['id'],
                'id_student' => $data_student['id'],
                'date' => $data['date'] ?? null, // Ambil 'date' dari JSON
                'note' => $data['note'] ?? null,
                'status' => $method
            ];
            $this->scanModel->save($uploadIpad);

            }else{
                $uploadIpad = [
                'id_employee' => $data_employee['id'],
                'id_student' => $data_student['id'],
                'status' => $method
            ];
            $this->scanModel->save($uploadIpad);

            }
            
            $updateIpad = [
                'status' => $method
            ];
            $this->ipadModel->update($data_ipad['id'], $updateIpad);

            // session()->setFlashdata('success', 'Data berhasil diproses!' . ($method ? ' [' . $method . ']' : ''));

            return $this->response->setJSON([
                'status' => 'success',
                'message' => $data_student['name']
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'processScan error: ' . $e->getMessage());
            session()->setFlashdata('error', 'Terjadi kesalahan server.');
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Terjadi kesalahan server.'
            ])->setStatusCode(500);
        }
    }

    

    public function class($params = "", $id = ""): string|RedirectResponse
    {
        if ($params == 'add') {
            $postData = $this->request->getPost();
            $this->classModel->save($postData);
            session()->setFlashdata("success", "Data Class has been successfully added!");
            return redirect()->to('siswa/kelas');
        } elseif ($params == 'update') {
            $postData = $this->request->getPost();
            $this->classModel->update($postData['id'], $postData);
            session()->setFlashdata("success", "Data Class has been successfully updated!");
            return redirect()->to('siswa/kelas');
        } elseif ($params == 'delete') {
            $this->classModel->delete($id);
            session()->setFlashdata("success", "Data Class has been successfully deleted!");
            return redirect()->to('siswa/kelas');
        } else {
            $classData = $this->classModel->findAll();
            return $this->_renderView('student/class', [
                'title' => 'Kelas',
                'hal' => '8',
                'class' => $classData,
            ]);
        }
    }

    

    

    public function history(): string
    {
        
        return $this->_renderView('student/scan_history', [
            'title' => 'History Scan',
            'hal' => '9',
            'count_all_ipad' => $this->ipadModel->countAllResults(),
            'count_rak_ipad' => $this->ipadModel->where('status', 'Disimpan')->countAllResults(),
            'count_class_ipad' => $this->ipadModel->where('status', 'Pembelajaran')->countAllResults(),
            'count_rent_ipad' => $this->ipadModel->where('status', 'Pinjam')->countAllResults()
        ]);
    }
}
