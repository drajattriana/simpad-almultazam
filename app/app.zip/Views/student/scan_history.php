<?= $this->extend('template/index') ?>

<?= $this->section('content') ?>

<style>
    /* Make the card header clickable */
    .collapsible-header {
        cursor: pointer;
        user-select: none;
    }

    /* Pastikan .card-title memenuhi lebar container */
    .collapsible-header .card-title {
        width: 100%;
    }

    /* Add an arrow icon to the header title */
    .collapsible-header .card-title::after {
        content: '\f068';
        /* Kode Unicode untuk ikon "minus" di FA5 */
        /* DIUBAH: Sesuaikan dengan nama font yang di-load di template Anda */
        font-family: 'Font Awesome 5 Solid';
        font-weight: 900;
        /* Penting untuk ikon Solid di FA5 */
        font-size: 12px;
        float: right;
        margin-left: 15px;
        transition: transform 0.3s ease;
    }

    /* The content to be hidden/shown */
    .collapsible-content {
        max-height: 1000px;
        overflow: hidden;
        transition: max-height 0.4s ease-in-out, padding 0.4s ease-in-out;
    }

    /* Style for when the card is minimized (inactive) */
    .card:not(.active) .collapsible-content {
        max-height: 0;
        padding-top: 0;
        padding-bottom: 0;
        border-top: none;
    }

    /* Change icon when minimized */
    .card:not(.active) .collapsible-header .card-title::after {
        content: '\f067';
        /* Kode Unicode untuk ikon "plus" di FA5 */
    }
</style>

<div class="container-fluid">
    


    <!-- DIUBAH: Tambah ID dan class .collapsible-card, hapus .active -->
    <div class="row">
        <div class="col-md-12">
            <div id="grafik-penggunaan" class="card collapsible-card active">
                <div class="card-header collapsible-header">
                    <div class="card-head-row">
                        <div class="card-title">Grafik Penggunaan Ipad</div>
                    </div>
                </div>
                <div class="card-body collapsible-content">
                    <div class="chart-container" style="min-height: 375px">
                        <canvas id="statisticsChart"></canvas>
                    </div>
                    <div id="myChartLegend"></div>
                </div>
            </div>
        </div>
    </div>
</div>



<?= $this->endSection() ?>



<?= $this->section('scripts') ?>
<script>
    $(document).ready(function() {

        
    // DataTable
    $('#roles-table').DataTable({});
    $('#roles-table2').DataTable({});
    $('#roles-table3').DataTable({});

        // --- FUNGSI UNTUK COLLAPSIBLE CARD ---

        // 1. Membuat semua header bisa diklik untuk toggle
        $('.collapsible-header').on('click', function() {
            $(this).closest('.card').toggleClass('active');
        });

        // 2. Fungsi saat tombol "Lihat Data" diklik
        $('.view-data-btn').on('click', function(e) {
            e.preventDefault(); // Mencegah link berpindah halaman

            // Ambil ID target dari atribut data-target
            var targetId = $(this).data('target');
            var $targetCard = $(targetId);

            // Jika target ada
            if ($targetCard.length) {
                // Tutup semua card LAIN yang sedang terbuka
                $('.collapsible-card.active').not($targetCard).removeClass('active');

                // Buka (atau toggle) card yang dituju
                $targetCard.toggleClass('active');

                // Jika card target sekarang aktif (terbuka), scroll ke sana
                if ($targetCard.hasClass('active')) {
                    $('html, body').animate({
                        scrollTop: $targetCard.offset().top - 80 // -80 agar ada jarak dari header
                    }, 500); // 500ms = kecepatan scroll
                }
            }
        });


        // --- KODE CHART ANDA (TIDAK BERUBAH) ---
        var ctx = document.getElementById('statisticsChart').getContext('2d');
        var statisticsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets: [{
                    label: "Total IPad untuk Pembelajaran",
                    borderColor: '#f3545d',
                    pointBackgroundColor: 'rgba(243, 84, 93, 0.2)',
                    pointRadius: 0,
                    backgroundColor: 'rgba(243, 84, 93, 0.1)',
                    legendColor: '#f3545d',
                    fill: true,
                    borderWidth: 2,
                    data: [154, 184, 175, 203, 210, 231, 240, 278, 252, 312, 320, 374]
                }, {
                    label: "Total IPad Di Pinjam",
                    borderColor: '#177dff',
                    pointBackgroundColor: 'rgba(23, 125, 255, 0.2)',
                    pointRadius: 0,
                    backgroundColor: 'rgba(23, 125, 255, 0.1)',
                    legendColor: '#177dff',
                    fill: true,
                    borderWidth: 2,
                    data: [542, 480, 430, 550, 530, 453, 380, 434, 568, 610, 700, 900]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                tooltips: {
                    bodySpacing: 4,
                    mode: "nearest",
                    intersect: 0,
                    position: "nearest",
                    xPadding: 10,
                    yPadding: 10,
                    caretPadding: 10
                },
                layout: {
                    padding: {
                        left: 15,
                        right: 15,
                        top: 15,
                        bottom: 15
                    }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            fontColor: "rgba(0,0,0,0.5)",
                            fontStyle: "500",
                            beginAtZero: false,
                            maxTicksLimit: 5,
                            padding: 20
                        },
                        gridLines: {
                            drawTicks: false,
                            display: false
                        }
                    }],
                    xAxes: [{
                        gridLines: {
                            zeroLineColor: "transparent"
                        },
                        ticks: {
                            padding: 20,
                            fontColor: "rgba(0,0,0,0.5)",
                            fontStyle: "500"
                        }
                    }]
                },
                legendCallback: function(chart) {
                    var text = [];
                    text.push('<ul class="' + chart.id + '-legend html-legend">');
                    for (var i = 0; i < chart.data.datasets.length; i++) {
                        text.push('<li><span style="background-color:' + chart.data.datasets[i].legendColor + '"></span>');
                        if (chart.data.datasets[i].label) {
                            text.push(chart.data.datasets[i].label);
                        }
                        text.push('</li>');
                    }
                    text.push('</ul>');
                    return text.join('');
                }
            }
        });

        var myLegendContainer = document.getElementById("myChartLegend");
        myLegendContainer.innerHTML = statisticsChart.generateLegend();
        var legendItems = myLegendContainer.getElementsByTagName('li');
        for (var i = 0; i < legendItems.length; i += 1) {
            legendItems[i].addEventListener("click", legendClickCallback, false);
        }
    });
</script>

<?= $this->endSection() ?>